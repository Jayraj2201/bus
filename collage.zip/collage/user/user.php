
<?php
$site_name = "My Cool Website";
?>

// index.php
<?php
include 'index.html';
echo $site_name; // Outputs: My Cool Website
?>
