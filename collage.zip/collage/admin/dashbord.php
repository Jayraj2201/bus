<?php
@include 'admin.html'
?>