<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

error_reporting(E_ALL);
ini_set('display_errors', 0); // Hide errors in JSON output

$servername = "localhost";
$username = "root";
$password = "";
$database = "bus_tracking";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

if (!isset($_GET['route_id']) || !is_numeric($_GET['route_id'])) {
    echo json_encode(["error" => "Invalid route_id"]);
    exit;
}

$route_id = intval($_GET['route_id']);
$sql = "SELECT schedule_id, stop_name, departure_time FROM bus_schedules WHERE route_id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["error" => "SQL error"]);
    exit;
}

$stmt->bind_param("i", $route_id);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($data, JSON_PRETTY_PRINT);
?>
